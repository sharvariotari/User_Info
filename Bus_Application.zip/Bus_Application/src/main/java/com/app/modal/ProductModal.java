package com.app.modal;

import com.app.pojos.Products;

public class ProductModal {
	private Products product;
	private ImageDTO image;
	
	public Products getProduct() {
		return product;
	}
	public void setProduct(Products product) {
		this.product = product;
	}
	public ImageDTO getImage() {
		return image;
	}
	public void setImage(ImageDTO image) {
		this.image = image;
	}
	
}
